//coisas que faltam: -organizar o titulo, arrumar isso e organizar o filtro

function troca(){
    document.getElementsById("blusa1").src= "moletom_canguru_back.png";
}

